package com.example.invmgmt.exception;

public class BaseException extends Exception {

    public BaseException(String err) {
        super(err);
    }

}
