SSDI 6112 Project:
Inventory Management Android App: This application is built to manage retail inventory.
Accessible by authorized users only
Inventory info includes: category, name, cost, selling price, recieved date, sold date
